import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Table, Spinner, Alert, Button, Card } from 'react-bootstrap';
import { useTheme } from '../context/ThemeContext'; // Ensure this path matches your project structure

const AdminUsers = () => {
    const [users, setUsers] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    
    // Get current theme
    const { theme } = useTheme();
    const isDark = theme === 'dark';

    const fetchUsers = async () => {
        try {
            const token = localStorage.getItem('adminToken');
            const res = await axios.get('http://localhost:5000/admin/users', {
                headers: { 'Authorization': `Bearer ${token}` }
            });
            setUsers(res.data);
            setLoading(false);
        } catch (err) {
            console.error("Error fetching users:", err);
            setError("Could not fetch user list.");
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchUsers();
    }, []);

    const handleDelete = async (userId) => {
        if (!window.confirm("Are you sure you want to delete this user?")) return;
        try {
            const token = localStorage.getItem('adminToken');
            await axios.delete(`http://localhost:5000/admin/delete-user/${userId}`, {
                headers: { 'Authorization': `Bearer ${token}` }
            });
            fetchUsers(); 
        } catch (err) {
            alert("Failed to delete user");
        }
    };

    if (loading) return (
        <div className="text-center mt-5">
            <Spinner animation="border" variant={isDark ? 'light' : 'primary'} />
        </div>
    );
    
    if (error) return <Alert variant="danger" className="m-4">{error}</Alert>;

    return (
        <div className="container pb-5">
            <h2 className={`mb-4 fw-bold ${isDark ? 'text-light' : 'text-primary'}`}>Manage Users</h2>
            
            {/* Dynamic Card Background */}
            <Card className={`shadow-sm ${isDark ? 'bg-dark text-white border-secondary' : 'border-0'}`}>
                <Card.Body className="p-0">
                    {/* Dynamic Table Variant */}
                    <Table hover responsive variant={isDark ? 'dark' : 'light'} className="mb-0 align-middle">
                        <thead className={isDark ? 'bg-secondary text-light' : 'bg-light text-secondary'}>
                            <tr>
                                <th className="ps-4 py-3">#</th>
                                <th className="py-3">Name</th>
                                <th className="py-3">Email</th>
                                <th className="py-3">Created At</th>
                                <th className="pe-4 py-3 text-end">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            {users.length > 0 ? (
                                users.map((user, index) => (
                                    <tr key={user._id}>
                                        <td className="ps-4">{index + 1}</td>
                                        <td className="fw-bold">{user.name}</td>
                                        <td>{user.email}</td>
                                        <td>{new Date(user.created_at).toLocaleDateString()}</td>
                                        <td className="pe-4 text-end">
                                            <Button 
                                                variant="outline-danger" 
                                                size="sm" 
                                                onClick={() => handleDelete(user._id)}
                                            >
                                                Delete
                                            </Button>
                                        </td>
                                    </tr>
                                ))
                            ) : (
                                <tr>
                                    <td colSpan="5" className="text-center py-4 text-muted">No users found.</td>
                                </tr>
                            )}
                        </tbody>
                    </Table>
                </Card.Body>
            </Card>
        </div>
    );
};

export default AdminUsers;