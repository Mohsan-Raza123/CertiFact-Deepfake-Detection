import React from 'react';
import { Link, Outlet, useNavigate, useLocation } from 'react-router-dom';
import { Navbar, Nav, Container, Button } from 'react-bootstrap';
import { useTheme } from '../context/ThemeContext'; // Import useTheme

const AdminLayout = () => {
    const navigate = useNavigate();
    const location = useLocation();
    const { theme, toggleTheme } = useTheme(); // Get theme context

    const handleLogout = () => {
        // Clear all potential tokens for a clean logout
        localStorage.removeItem('adminToken');
        localStorage.removeItem('token');
        localStorage.removeItem('authToken');
        localStorage.removeItem('adminName');
        navigate('/login');
    };

    const isActive = (path) => location.pathname === path ? 'active fw-bold' : '';
    const isDark = theme === 'dark';

    return (
        // Dynamic Background Color based on Theme
        <div className={`d-flex flex-column min-vh-100 ${isDark ? 'bg-dark text-light' : 'bg-light text-dark'}`} 
             style={{ backgroundColor: isDark ? '#121212' : '#f8f9fa' }}>
            
            {/* Top Navigation Bar */}
            <Navbar 
                bg={isDark ? 'dark' : 'white'} 
                variant={isDark ? 'dark' : 'light'} 
                expand="lg" 
                className={`shadow-sm mb-4 border-bottom ${isDark ? 'border-secondary' : ''}`}
            >
                <Container>
                    <Navbar.Brand as={Link} to="/admin/dashboard" className="text-primary fw-bold">
                        CertiFact <span className={`badge border ms-2 ${isDark ? 'bg-secondary text-light' : 'bg-light text-dark'}`}>Admin</span>
                    </Navbar.Brand>
                    
                    <Navbar.Toggle aria-controls="basic-navbar-nav" />
                    <Navbar.Collapse id="basic-navbar-nav">
                        <Nav className="me-auto ms-3">
                            <Nav.Link as={Link} to="/admin/dashboard" className={isActive('/admin/dashboard')}>Dashboard</Nav.Link>
                            <Nav.Link as={Link} to="/admin/users" className={isActive('/admin/users')}>Users</Nav.Link>
                            <Nav.Link as={Link} to="/admin/uploads" className={isActive('/admin/uploads')}>Uploads</Nav.Link>
                            <Nav.Link as={Link} to="/admin/logs" className={isActive('/admin/logs')}>Logs</Nav.Link>
                            {/* --- ADDED SETTINGS LINK --- */}
                            <Nav.Link as={Link} to="/admin/settings" className={isActive('/admin/settings')}>Settings</Nav.Link>
                        </Nav>
                        
                        <div className="d-flex align-items-center">
                            {/* Theme Toggle Button */}
                            <Button variant={isDark ? "outline-light" : "outline-dark"} size="sm" className="me-3" onClick={toggleTheme}>
                                {isDark ? '☀️ Light' : '🌙 Dark'}
                            </Button>

                            <span className={`me-3 small ${isDark ? 'text-white-50' : 'text-muted'}`}>Administrator</span>
                            <Button variant="outline-danger" size="sm" onClick={handleLogout}>
                                Logout
                            </Button>
                        </div>
                    </Navbar.Collapse>
                </Container>
            </Navbar>

            {/* Content Area */}
            <div className="flex-grow-1">
                <Outlet />
            </div>
        </div>
    );
};

export default AdminLayout;