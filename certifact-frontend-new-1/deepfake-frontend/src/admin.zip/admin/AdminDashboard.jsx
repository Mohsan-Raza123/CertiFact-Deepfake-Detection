import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Card, Row, Col, Spinner, Alert } from 'react-bootstrap';
import { useNavigate } from 'react-router-dom';
import { Chart as ChartJS, ArcElement, Tooltip, Legend } from 'chart.js';
import { Doughnut } from 'react-chartjs-2';
import { useTheme } from '../context/ThemeContext'; 

ChartJS.register(ArcElement, Tooltip, Legend);

const AdminDashboard = () => {
    const [stats, setStats] = useState({
        total_users: 0,
        total_uploads: 0,
        total_admins: 0
    });
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const navigate = useNavigate();
    const { theme } = useTheme(); // Get current theme (light or dark)

    useEffect(() => {
        const fetchStats = async () => {
            try {
                const token = localStorage.getItem('adminToken');
                if (!token) throw new Error("No admin token found.");

                const res = await axios.get('http://localhost:5000/admin/stats', {
                    headers: { 'Authorization': `Bearer ${token}` }
                });
                
                setStats(res.data);
                setLoading(false);
            } catch (err) {
                if (err.response && (err.response.status === 401 || err.response.status === 422)) {
                    localStorage.removeItem('adminToken');
                    navigate('/login');
                    return;
                }
                setError("Failed to load dashboard statistics.");
                setLoading(false);
            }
        };
        fetchStats();
    }, [navigate]);

    if (loading) return <div className="text-center p-5"><Spinner animation="border" variant="primary" /></div>;
    if (error) return <Alert variant="danger" className="m-4">{error}</Alert>;

    // === THEME STYLING HELPERS ===
    const isDark = theme === 'dark';
    const cardClass = isDark ? 'bg-dark text-light border-secondary' : 'bg-white text-dark border-0';
    const textMuted = isDark ? 'text-white-50' : 'text-muted';
    const listGroupClass = isDark ? 'bg-dark text-light border-secondary' : 'bg-white text-dark';
    const chartTextColor = isDark ? '#e0e0e0' : '#212529';

    // Chart Data
    const chartData = {
        labels: ['Registered Users', 'System Admins'],
        datasets: [
            {
                data: [stats.total_users, stats.total_admins],
                backgroundColor: ['rgba(54, 162, 235, 0.7)', 'rgba(255, 206, 86, 0.7)'],
                borderColor: ['rgba(54, 162, 235, 1)', 'rgba(255, 206, 86, 1)'],
                borderWidth: 1,
            },
        ],
    };

    const chartOptions = {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: {
                position: 'bottom',
                labels: { color: chartTextColor },
            },
        },
    };

    return (
        <div className="container pb-5">
            <h1 className={`mb-4 fw-bold ${isDark ? 'text-light' : 'text-primary'}`}>
                Admin Dashboard
            </h1>

            {/* Stat Cards */}
            <Row className="g-4 mb-4">
                <Col md={4}>
                    <Card className={`shadow-sm h-100 ${cardClass}`}>
                        <Card.Body className="text-center">
                            <Card.Title className={textMuted}>Total Users</Card.Title>
                            <Card.Text className="display-4 fw-bold text-primary">{stats.total_users}</Card.Text>
                        </Card.Body>
                    </Card>
                </Col>
                <Col md={4}>
                    <Card className={`shadow-sm h-100 ${cardClass}`}>
                        <Card.Body className="text-center">
                            <Card.Title className={textMuted}>Total Analyses</Card.Title>
                            <Card.Text className="display-4 fw-bold text-success">{stats.total_uploads}</Card.Text>
                        </Card.Body>
                    </Card>
                </Col>
                <Col md={4}>
                    <Card className={`shadow-sm h-100 ${cardClass}`}>
                        <Card.Body className="text-center">
                            <Card.Title className={textMuted}>Admins</Card.Title>
                            <Card.Text className="display-4 fw-bold text-warning">{stats.total_admins}</Card.Text>
                        </Card.Body>
                    </Card>
                </Col>
            </Row>

            <Row className="g-4">
                {/* User Distribution Chart */}
                <Col lg={6}>
                    <Card className={`shadow-sm h-100 ${cardClass}`}>
                        <Card.Header as="h5" className={`${isDark ? 'border-secondary' : 'border-bottom'} pt-3`}>
                            User Distribution
                        </Card.Header>
                        <Card.Body className="d-flex justify-content-center align-items-center" style={{ minHeight: '300px' }}>
                             <div style={{ height: '250px', width: '100%' }}>
                                <Doughnut data={chartData} options={chartOptions} />
                             </div>
                        </Card.Body>
                    </Card>
                </Col>

                {/* System Health */}
                <Col lg={6}>
                    <Card className={`shadow-sm h-100 ${cardClass}`}>
                        <Card.Header as="h5" className={`${isDark ? 'border-secondary' : 'border-bottom'} pt-3`}>
                            System Health
                        </Card.Header>
                        <Card.Body>
                            <ul className="list-group list-group-flush">
                                <li className={`list-group-item d-flex justify-content-between align-items-center px-0 ${listGroupClass}`}>
                                    <span>Server Status</span>
                                    <span className="badge bg-success rounded-pill">Online</span>
                                </li>
                                <li className={`list-group-item d-flex justify-content-between align-items-center px-0 ${listGroupClass}`}>
                                    <span>Database Connection</span>
                                    <span className="badge bg-success rounded-pill">Connected</span>
                                </li>
                                <li className={`list-group-item d-flex justify-content-between align-items-center px-0 ${listGroupClass}`}>
                                    <span>AI Model Status</span>
                                    <span className="badge bg-success rounded-pill">Ready</span>
                                </li>
                            </ul>
                            <div className="mt-4">
                                <small className={textMuted}>Last System Update: Just now</small>
                            </div>
                        </Card.Body>
                    </Card>
                </Col>
            </Row>
        </div>
    );
};

export default AdminDashboard;