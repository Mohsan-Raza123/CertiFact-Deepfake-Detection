import React, { useState } from 'react';
import axios from 'axios';

// --- Inline SVG Icons ---
const EyeIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" className="bi bi-eye" viewBox="0 0 16 16">
    <path d="M16 8s-3-5.5-8-5.5S0 8 0 8s3 5.5 8 5.5S16 8 16 8zM1.173 8a13.133 13.133 0 0 1 1.66-2.043C4.12 4.668 5.88 3.5 8 3.5c2.12 0 3.879 1.168 5.168 2.457A13.133 13.133 0 0 1 14.828 8c-.058.087-.122.183-.195.288-.335.48-.83 1.12-1.465 1.755C11.879 11.332 10.119 12.5 8 12.5c-2.12 0-3.879-1.168-5.168-2.457A13.134 13.134 0 0 1 1.172 8z"/>
    <path d="M8 5.5a2.5 2.5 0 1 0 0 5 2.5 2.5 0 0 0 0-5zM4.5 8a3.5 3.5 0 1 1 7 0 3.5 3.5 0 0 1-7 0z"/>
  </svg>
);

const EyeSlashIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" className="bi bi-eye-slash" viewBox="0 0 16 16">
    <path d="M13.359 11.238C15.06 9.72 16 8 16 8s-3-5.5-8-5.5a7.028 7.028 0 0 0-2.79.588l.77.771A5.944 5.944 0 0 1 8 3.5c2.12 0 3.879 1.168 5.168 2.457A13.134 13.134 0 0 1 14.828 8c-.058.087-.122.183-.195.288-.335.48-.83 1.12-1.465 1.755-.165.165-.337.328-.517.486l.708.709z"/>
    <path d="M11.297 9.377 8 6.081l-1.42 1.42L8 9.213l3.297.164.002-.001-2.002-2.002-3-3L11.297 9.377zm-5.003-.591L2.404 4.908a7.03 7.03 0 0 0-1.23.957C.12 6.968 0 8 0 8s3 5.5 8 5.5c1.86 0 3.65-.63 5.087-1.74l1.246 1.246 1.414-1.414-10-10-1.414 1.414z"/>
  </svg>
);

const AdminSettings = () => {
  const [formData, setFormData] = useState({
    currentPassword: '',
    newPassword: '',
    confirmPassword: ''
  });
  
  const [showPassword, setShowPassword] = useState({
    current: false,
    new: false,
    confirm: false
  });
  
  const [message, setMessage] = useState({ type: '', text: '' });
  const [loading, setLoading] = useState(false);

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const toggleVisibility = (field) => {
    setShowPassword({ ...showPassword, [field]: !showPassword[field] });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setMessage({ type: '', text: '' });

    if (formData.newPassword !== formData.confirmPassword) {
      setMessage({ type: 'danger', text: 'New passwords do not match!' });
      return;
    }

    if (formData.newPassword.length < 6) {
        setMessage({ type: 'danger', text: 'New password must be at least 6 characters.' });
        return;
    }

    try {
      setLoading(true);
      
      const token = localStorage.getItem('adminToken');

      if (!token) {
        setMessage({ type: 'danger', text: 'Admin session expired. Please login again.' });
        setLoading(false);
        return;
      }

      await axios.post('http://localhost:5000/admin/change-password', 
        {
          current_password: formData.currentPassword,
          new_password: formData.newPassword
        },
        {
          headers: { Authorization: `Bearer ${token}` }
        }
      );

      setMessage({ type: 'success', text: 'Admin password updated successfully!' });
      setFormData({ currentPassword: '', newPassword: '', confirmPassword: '' });

    } catch (err) {
      console.error("Admin Change Password Error:", err);
      setMessage({ 
        type: 'danger', 
        text: err.response?.data?.msg || 'Failed to update password.' 
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container mt-4">
      <div className="card shadow-sm mx-auto" style={{ maxWidth: '600px' }}>
        <div className="card-header bg-dark text-white">
          <h4 className="mb-0">Admin Security Settings</h4>
        </div>
        <div className="card-body">
          <h5 className="card-title mb-4">Change Admin Password</h5>
          
          {message.text && (
            <div className={`alert alert-${message.type}`} role="alert">
              {message.text}
            </div>
          )}

          <form onSubmit={handleSubmit}>
            <div className="mb-3">
              <label className="form-label">Current Password</label>
              <div className="input-group">
                <input
                  type={showPassword.current ? "text" : "password"}
                  className="form-control"
                  name="currentPassword"
                  value={formData.currentPassword}
                  onChange={handleChange}
                  required
                />
                <button 
                  className="btn btn-outline-secondary" 
                  type="button"
                  onClick={() => toggleVisibility('current')}
                >
                  {showPassword.current ? <EyeSlashIcon /> : <EyeIcon />}
                </button>
              </div>
            </div>

            <div className="mb-3">
              <label className="form-label">New Password</label>
              <div className="input-group">
                <input
                  type={showPassword.new ? "text" : "password"}
                  className="form-control"
                  name="newPassword"
                  value={formData.newPassword}
                  onChange={handleChange}
                  required
                />
                <button 
                  className="btn btn-outline-secondary" 
                  type="button"
                  onClick={() => toggleVisibility('new')}
                >
                  {showPassword.new ? <EyeSlashIcon /> : <EyeIcon />}
                </button>
              </div>
            </div>

            <div className="mb-3">
              <label className="form-label">Confirm New Password</label>
              <div className="input-group">
                <input
                  type={showPassword.confirm ? "text" : "password"}
                  className="form-control"
                  name="confirmPassword"
                  value={formData.confirmPassword}
                  onChange={handleChange}
                  required
                />
                <button 
                  className="btn btn-outline-secondary" 
                  type="button"
                  onClick={() => toggleVisibility('confirm')}
                >
                  {showPassword.confirm ? <EyeSlashIcon /> : <EyeIcon />}
                </button>
              </div>
            </div>

            <button type="submit" className="btn btn-dark w-100" disabled={loading}>
              {loading ? 'Updating...' : 'Update Admin Password'}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default AdminSettings;