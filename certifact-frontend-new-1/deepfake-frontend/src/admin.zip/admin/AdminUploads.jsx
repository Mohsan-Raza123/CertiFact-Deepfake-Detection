import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useTheme } from '../context/ThemeContext'; // This path is correct for your local project

const AdminUploads = () => {
    const [uploads, setUploads] = useState([]);
    const [loading, setLoading] = useState(true);

    // Get current theme for Dark Mode support
    const { theme } = useTheme();
    const isDark = theme === 'dark';

    useEffect(() => {
        const fetchUploads = async () => {
            try {
                // Ensure we get the correct token regardless of login method
                const token = localStorage.getItem('adminToken') || localStorage.getItem('token');
                
                // Use full URL to avoid port 5173/5000 confusion
                const res = await axios.get('http://localhost:5000/admin/uploads', {
                    headers: { Authorization: `Bearer ${token}` }
                });
                setUploads(res.data);
            } catch (err) {
                console.error("Error fetching uploads:", err);
            } finally {
                setLoading(false);
            }
        };

        fetchUploads();
    }, []);

    // Helper to determine the correct image source from backend data
    const getMediaSrc = (item) => {
        // Prioritize thumbnail, fallback to original file
        const path = item.thumbnail_url || item.file_url;
        
        if (!path) return 'https://via.placeholder.com/100?text=No+Image';
        
        // Ensure the path is absolute pointing to Flask server
        return `http://localhost:5000${path}`;
    };

    if (loading) return (
        <div className={`p-4 text-center ${isDark ? 'text-light' : 'text-dark'}`}>
            Loading uploads...
        </div>
    );

    return (
        <div className="container-fluid p-4">
            <h2 className={`mb-4 fw-bold ${isDark ? 'text-light' : 'text-primary'}`}>
                Uploads & Detections
            </h2>
            
            <div className={`table-responsive shadow-sm rounded ${isDark ? 'border border-secondary' : ''}`}>
                <table className={`table table-hover mb-0 align-middle ${isDark ? 'table-dark' : 'bg-white'}`}>
                    <thead className={isDark ? 'bg-secondary text-light' : 'table-dark'}>
                        <tr>
                            <th>File Name</th>
                            <th>Preview</th>
                            <th>Type</th>
                            <th>Prediction</th>
                            <th>Confidence</th>
                            <th>Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        {uploads.map((up) => (
                            <tr key={up._id}>
                                {/* 1. File Name */}
                                <td style={{maxWidth: '250px', wordWrap: 'break-word'}}>
                                    {up.filename}
                                </td>

                                {/* 2. Thumbnail / Image Preview */}
                                <td>
                                    <a href={`http://localhost:5000${up.file_url}`} target="_blank" rel="noopener noreferrer">
                                        <img 
                                            src={getMediaSrc(up)} 
                                            alt="Preview" 
                                            className="rounded border"
                                            style={{ width: '80px', height: '80px', objectFit: 'cover' }}
                                            onError={(e) => {
                                                e.target.onerror = null; 
                                                e.target.src="https://via.placeholder.com/80?text=Error"
                                            }}
                                        />
                                    </a>
                                </td>

                                {/* 3. Type (Image/Video) */}
                                <td>
                                    <span className={`badge rounded-pill ${up.type === 'video' ? 'bg-info text-dark' : 'bg-primary'}`}>
                                        {up.type ? up.type.toUpperCase() : 'UNKNOWN'}
                                    </span>
                                </td>

                                {/* 4. Prediction */}
                                <td>
                                    {up.label ? (
                                        <span className={`fw-bold px-2 py-1 rounded ${
                                            up.label === 'Real' 
                                                ? (isDark ? 'bg-success text-white' : 'bg-success bg-opacity-10 text-success')
                                                : (isDark ? 'bg-danger text-white' : 'bg-danger bg-opacity-10 text-danger')
                                        }`}>
                                            {up.label}
                                        </span>
                                    ) : (
                                        <span className={`fst-italic ${isDark ? 'text-white-50' : 'text-muted'}`}>Pending</span>
                                    )}
                                </td>

                                {/* 5. Confidence Score */}
                                <td>
                                    {up.confidence_percent ? (
                                        <div className="d-flex align-items-center">
                                            <div className="progress flex-grow-1" style={{height: '6px', width: '60px', backgroundColor: isDark ? '#444' : '#e9ecef'}}>
                                                <div 
                                                    className={`progress-bar ${up.label === 'Real' ? 'bg-success' : 'bg-danger'}`} 
                                                    role="progressbar" 
                                                    style={{width: `${up.confidence_percent}%`}}
                                                ></div>
                                            </div>
                                            <span className="ms-2 small">{up.confidence_percent}%</span>
                                        </div>
                                    ) : 'N/A'}
                                </td>

                                {/* 6. Timestamp */}
                                <td className={`small ${isDark ? 'text-white-50' : 'text-muted'}`}>
                                    {new Date(up.timestamp).toLocaleString()}
                                </td>
                            </tr>
                        ))}
                        {uploads.length === 0 && (
                            <tr>
                                <td colSpan="6" className={`text-center py-5 ${isDark ? 'text-white-50' : 'text-muted'}`}>
                                    No uploads found.
                                </td>
                            </tr>
                        )}
                    </tbody>
                </table>
            </div>
        </div>
    );
};

export default AdminUploads;