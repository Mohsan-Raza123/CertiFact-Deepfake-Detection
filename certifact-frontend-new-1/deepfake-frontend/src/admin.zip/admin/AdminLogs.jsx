import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Card, Spinner, Badge } from 'react-bootstrap';
import { useTheme } from '../context/ThemeContext'; // This path is correct for your local project

const AdminLogs = () => {
    const [logs, setLogs] = useState([]);
    const [loading, setLoading] = useState(true);
    
    // Get current theme for Dark Mode support
    const { theme } = useTheme();
    const isDark = theme === 'dark';

    useEffect(() => {
        const fetchLogs = async () => {
            try {
                // Check all token types to ensure we find the valid one
                const token = localStorage.getItem('adminToken') || localStorage.getItem('token');
                
                // Use the full URL to ensure we hit the Flask backend (Port 5000)
                const res = await axios.get('http://localhost:5000/admin/logs', {
                    headers: { 'Authorization': `Bearer ${token}` }
                });
                setLogs(res.data);
            } catch (err) {
                console.error("Error fetching logs", err);
            } finally {
                setLoading(false);
            }
        };
        fetchLogs();
    }, []);

    if (loading) return (
        <div className="text-center mt-5">
            <Spinner animation="border" variant={isDark ? 'light' : 'primary'} />
        </div>
    );

    return (
        <div className="container pb-5">
            <h2 className={`mb-4 fw-bold ${isDark ? 'text-light' : 'text-primary'}`}>System Logs</h2>
            
            <Card className={`shadow-sm ${isDark ? 'bg-dark text-white border-secondary' : 'border-0'}`}>
                {/* Dynamic Header */}
                <Card.Header className={`${isDark ? 'bg-dark border-secondary text-white' : 'bg-white'} py-3`}>
                    <h5 className="mb-0">Recent Activity</h5>
                </Card.Header>
                
                <ul className="list-group list-group-flush">
                    {logs.length > 0 ? (
                        logs.map((l) => (
                            // Dynamic List Item
                            <li 
                                key={l._id} 
                                className={`list-group-item d-flex justify-content-between align-items-center py-3 ${isDark ? 'bg-dark text-white border-secondary' : ''}`}
                            >
                                <div>
                                    <Badge bg={isDark ? "secondary" : "primary"} className="me-2">{l.action}</Badge>
                                    <span className={isDark ? "text-light" : "text-dark"}>{l.details}</span>
                                </div>
                                <small className={isDark ? "text-white-50" : "text-muted"}>
                                    {new Date(l.timestamp).toLocaleString()}
                                </small>
                            </li>
                        ))
                    ) : (
                        <li className={`list-group-item text-center py-4 ${isDark ? 'bg-dark text-white-50 border-secondary' : 'text-muted'}`}>
                            No logs available
                        </li>
                    )}
                </ul>
            </Card>
        </div>
    );
};

export default AdminLogs;