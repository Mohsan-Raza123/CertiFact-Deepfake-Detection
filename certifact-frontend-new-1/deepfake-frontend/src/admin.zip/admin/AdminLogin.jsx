import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios'; 

const AdminLogin = () => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');
    const navigate = useNavigate();

    const handleLogin = async (e) => {
        e.preventDefault();
        setError(''); // Clear previous errors
        
        try {
            // ---------------------------------------------------------
            // FIX IS HERE: We explicitly use http://localhost:5000
            // ---------------------------------------------------------
            const res = await axios.post('http://localhost:5000/admin/login', { 
                email, 
                password 
            });

            // If successful:
            localStorage.setItem('adminToken', res.data.access_token);
            navigate('/admin/dashboard');
        } catch (err) {
            console.error("Login Error Details:", err); // See console for real error
            
            if (err.response && err.response.status === 401) {
                setError('Invalid Email or Password');
            } else if (err.code === "ERR_NETWORK") {
                setError('Cannot connect to Backend (Is Flask running on port 5000?)');
            } else {
                setError('Login Failed. Check console for details.');
            }
        }
    };

    return (
        <div className="d-flex justify-content-center align-items-center vh-100 bg-light" style={{ height: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', backgroundColor: '#f8f9fa' }}>
            <div className="card p-4 shadow" style={{ width: '400px', padding: '20px', background: 'white', borderRadius: '8px', boxShadow: '0 4px 6px rgba(0,0,0,0.1)' }}>
                <h3 className="text-center mb-3" style={{ textAlign: 'center', marginBottom: '20px' }}>Admin Portal</h3>
                
                {error && (
                    <div className="alert alert-danger" style={{ padding: '10px', backgroundColor: '#f8d7da', color: '#721c24', borderRadius: '4px', marginBottom: '15px' }}>
                        {error}
                    </div>
                )}
                
                <form onSubmit={handleLogin}>
                    <div className="mb-3" style={{ marginBottom: '15px' }}>
                        <label style={{ display: 'block', marginBottom: '5px' }}>Email</label>
                        <input 
                            className="form-control" 
                            type="email" 
                            value={email}
                            onChange={e => setEmail(e.target.value)} 
                            required 
                            style={{ width: '100%', padding: '8px', borderRadius: '4px', border: '1px solid #ccc' }}
                        />
                    </div>
                    <div className="mb-3" style={{ marginBottom: '20px' }}>
                        <label style={{ display: 'block', marginBottom: '5px' }}>Password</label>
                        <input 
                            className="form-control" 
                            type="password" 
                            value={password}
                            onChange={e => setPassword(e.target.value)} 
                            required 
                            style={{ width: '100%', padding: '8px', borderRadius: '4px', border: '1px solid #ccc' }}
                        />
                    </div>
                    <button 
                        className="btn btn-dark w-100" 
                        style={{ width: '100%', padding: '10px', backgroundColor: '#343a40', color: 'white', border: 'none', borderRadius: '4px', cursor: 'pointer' }}
                    >
                        Login
                    </button>
                </form>
            </div>
        </div>
    );
};
export default AdminLogin;